Add any Java JAR's that you want to be included in your Lambda function in this directory.
