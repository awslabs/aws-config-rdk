rdk
---

Rules Development Kit - Version 2

Extremely Alpha.  Do not use if you haven't talked to me.
